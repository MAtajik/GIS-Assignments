# Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
# The following inputs are layers or table views: "ned"
arcpy.gp.Fill_sa("ned", "E:/desktop/LAMAR UNIVERSITY/MES CE/Fall 23/CVEN_5370_GISAppsInEngineering/Assignment5/Assignment5/Assignment5.gdb/nedFill", "")
# Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
# The following inputs are layers or table views: "nedFill"
arcpy.gp.FlowDirection_sa("nedFill", "E:/desktop/LAMAR UNIVERSITY/MES CE/Fall 23/CVEN_5370_GISAppsInEngineering/Assignment5/Assignment5/Assignment5.gdb/nedfdr", "NORMAL", "", "D8")
# Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
# The following inputs are layers or table views: "nedfdr"
arcpy.gp.FlowAccumulation_sa("nedfdr", "E:/desktop/LAMAR UNIVERSITY/MES CE/Fall 23/CVEN_5370_GISAppsInEngineering/Assignment5/Assignment5/Assignment5.gdb/nedfacc", "", "FLOAT", "D8")
arcpy.gp.RasterCalculator_sa('"nedfacc"  >= 500', "E:/desktop/LAMAR UNIVERSITY/MES CE/Fall 23/CVEN_5370_GISAppsInEngineering/Assignment5/Assignment5/Assignment5.gdb/streams")
# Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
# The following inputs are layers or table views: "outlet", "nedfacc"
arcpy.gp.SnapPourPoint_sa("outlet", "nedfacc", "E:/desktop/LAMAR UNIVERSITY/MES CE/Fall 23/CVEN_5370_GISAppsInEngineering/Assignment5/Assignment5/Assignment5.gdb/nedout", "30", "Id")
# Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
# The following inputs are layers or table views: "nedfdr", "nedout"
arcpy.gp.Watershed_sa("nedfdr", "nedout", "E:/desktop/LAMAR UNIVERSITY/MES CE/Fall 23/CVEN_5370_GISAppsInEngineering/Assignment5/Assignment5/Assignment5.gdb/watershed", "Value")
# Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
# The following inputs are layers or table views: "watershed"
arcpy.RasterToPolygon_conversion(in_raster="watershed", out_polygon_features="E:/desktop/LAMAR UNIVERSITY/MES CE/Fall 23/CVEN_5370_GISAppsInEngineering/Assignment5/Assignment5/Assignment5.gdb/watershed_polygon", simplify="SIMPLIFY", raster_field="Value", create_multipart_features="SINGLE_OUTER_PART", max_vertices_per_feature="")
